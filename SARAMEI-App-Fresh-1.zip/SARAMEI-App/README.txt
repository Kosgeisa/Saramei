SARAMEI APP (installable web app / PWA)

This package turns the SARAMEI notes website into an installable app-like experience.

IMPORTANT: To install on Android, first publish this folder on a website using HTTPS (for example, your web host). An app cannot be installed from an ordinary local file.

TEST ON YOUR COMPUTER
1. Open this folder in Visual Studio Code.
2. Install/use the Live Server extension and choose “Go Live”.
3. For full PWA install testing, use a secure HTTPS host; localhost is accepted for local testing.

INSTALL ON ANDROID
1. Open the published HTTPS site in Chrome.
2. Open Chrome menu (⋮).
3. Choose “Install app” or “Add to Home screen” (wording may vary).
4. Confirm. SARAMEI will appear among your apps.

CURRENT LIMITATIONS
- This is an installable web app, not yet a Play Store APK.
- The notes manager is a browser demo and has no secure admin login. Notes saved on one browser are not automatically shared with students.
- Offline mode can keep the app shell available, but it does not synchronize or distribute notes from the demo.
- For public student access, connect a real backend/database, file storage, and secure administrator accounts, then publish over HTTPS.
